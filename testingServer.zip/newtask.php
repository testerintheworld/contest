<html>
<head>
	<title> <?php if ($type < 3) {?>Новая задача<?php } else { ?> Error| Ошибка<?php } ?></title>
<style>
</style>
<script src="assest/js/jquery-3.2.0.min.js"></script>
<script>
</script>
<meta charset="utf-8">
<link type="text/css" rel="stylesheet" href="assest/css/style.css">
</head>
<body>
    <?php
        include('srchead');
    ?>
<?php include("tasks"); 
/*
$file = fopen('srctask','r'); #ТОЛЬКО НА ЧТЕНИЕ
fwrite($file, $text);
$text = file_get_contents("tasks");
fclose($file);
*/
?>
<div id="body">
  <div id="general_content" style="width: 100%;">  
    <div id="post"><! contenteditable="true">
      <?php if ($type < 3) {?>
        <form name="newtask" action="createTask.php">
          <a onclick="checktask()" style="left: 10px; bottom: 100px; position: fixed; border: 1px solid #333; border-radius: 50px; padding: 5px; background: #fff; z-index: 10;">Просмотр</a>
          <h1>Новая задача:</h1>
          Название:
          <input type="text" name="name" style="width: 100%;">
          Текст задачи:
          <textarea name="text" style="width: 100%; height: 300px; resize: fixed;"></textarea>
          Входные данные:
          <textarea name="text" style="width: 100%; height: 100px;"></textarea>
          Выходные данные:
          <textarea name="text" style="width: 100%; height: 100px;"></textarea>

        </form>
        <?php } else { ?> Sorry, this page not found. After 5 seconds you will be redirected to the main page.<br>К сожалению, эта страница не найдена. Через 5 секунд вы будете перенаправлены на главную страницу.<?php } ?>
    </div>
  </div>
</div>
    <?php 
    include("srcfooter");
    ?>

</body>
</html>